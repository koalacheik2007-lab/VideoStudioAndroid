#!/usr/bin/env python3
"""Vidéos 9:16 : recadrage, effacement des sous-titres, zoom, micro-shake, miroir, texte. Export MP4 avec le son.

Installation :  pip install opencv-python numpy pillow   (+ FFmpeg dans le PATH)
Interface    :  python video_app.py
Automatique  :  python video_app.py --entrees MES_VIDEOS --sorties RESULTATS [--surveiller]
"""
import argparse, math, queue, random, shutil, subprocess, sys, tempfile, threading, time
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

EXT = {".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v"}
POLICES = ["DejaVuSans-Bold.ttf", "arialbd.ttf", "Arial Bold.ttf", "Arial.ttf",
           "Helvetica.ttc", "/System/Library/Fonts/Helvetica.ttc", "segoeuib.ttf"]
OPT_DEFAUT = dict(texte="Rêve fulgurante", miroir=5.0, sous_titres=True)


def charger_police(taille):
    for nom in POLICES:
        try:
            return ImageFont.truetype(nom, taille)
        except OSError:
            continue
    try:
        return ImageFont.load_default(size=taille)
    except TypeError:
        return ImageFont.load_default()


def creer_overlay(w, h, texte):
    """Texte rendu une seule fois avec Pillow (accents OK). Retourne (zone, pixels) ou None."""
    if not texte:
        return None
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ImageDraw.Draw(img).text((int(w * 0.06), int(h * 0.04)), texte,
                             font=charger_police(max(18, int(h * 0.035))), fill=(255, 255, 255, 255))
    arr = np.array(img)
    ys, xs = np.nonzero(arr[..., 3])
    if len(ys) == 0:
        return None
    y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    return (y0, y1, x0, x1), arr[y0:y1, x0:x1]


def poser_texte(frame, overlay):
    if overlay is None:
        return frame
    (y0, y1, x0, x1), ov = overlay
    a = ov[..., 3:4].astype(np.float32) / 255
    zone = frame[y0:y1, x0:x1].astype(np.float32)
    frame[y0:y1, x0:x1] = (ov[..., :3] * a + zone * (1 - a)).astype(np.uint8)
    return frame


def traiter_video(entree, sortie, opt, progression=lambda f: None, annule=None):
    """Retourne True si terminé, False si annulé. Lève RuntimeError en cas d'échec."""
    cap = cv2.VideoCapture(str(entree))
    if not cap.isOpened():
        raise RuntimeError("impossible d'ouvrir la vidéo")
    W, H = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    if not fps or fps <= 0 or fps > 120:
        fps = 30
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 0

    H -= H % 2                                  # dimensions paires obligatoires
    nw = min(W, int(H * 9 / 16))                # si la vidéo est déjà plus étroite, on garde tout
    nw -= nw % 2
    x0 = (W - nw) // 2
    overlay = creer_overlay(nw, H, opt["texte"])

    log = tempfile.TemporaryFile()
    cmd = ["ffmpeg", "-y", "-loglevel", "error",
           "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{nw}x{H}", "-framerate", str(fps), "-i", "-",
           "-i", str(entree), "-map", "0:v", "-map", "1:a?",            # conserve le son d'origine
           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "20", "-preset", "medium",
           "-c:a", "aac", "-movflags", "+faststart", "-shortest", str(sortie)]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=log)

    n, annule_flag = 0, False
    try:
        while True:
            if annule is not None and annule.is_set():
                annule_flag = True
                break
            ok, frame = cap.read()
            if not ok:
                break
            t = n / fps
            f = np.ascontiguousarray(frame[:H, x0:x0 + nw])

            if opt["sous_titres"]:              # effacement des sous-titres (bas 20 %)
                masque = np.zeros(f.shape[:2], np.uint8)
                masque[int(H * 0.8):] = 255
                f = cv2.inpaint(f, masque, 3, cv2.INPAINT_TELEA)

            z = 1 + 0.03 * (0.5 - 0.5 * math.cos(2 * math.pi * t / 20))   # zoom progressif, cycle 20 s
            if z > 1.0005:
                nh, nl = int(H / z), int(nw / z)
                top, left = (H - nh) // 2, (nw - nl) // 2
                f = cv2.resize(f[top:top + nh, left:left + nl], (nw, H))

            M = np.float32([[1, 0, random.randint(-2, 2)], [0, 1, random.randint(-2, 2)]])
            f = cv2.warpAffine(f, M, (nw, H), borderMode=cv2.BORDER_REPLICATE)   # pas de bords noirs

            if opt["miroir"] > 0 and int(t // opt["miroir"]) % 2 == 1:
                f = np.ascontiguousarray(f[:, ::-1])

            f = poser_texte(f, overlay)
            proc.stdin.write(f.tobytes())
            n += 1
            if total and n % 5 == 0:
                progression(min(n / total, 0.99))
    except BrokenPipeError:
        pass
    finally:
        cap.release()
        try:
            proc.stdin.close()
        except Exception:
            pass
        code = proc.wait()

    if annule_flag:
        Path(sortie).unlink(missing_ok=True)
        log.close()
        return False
    if code != 0 or n == 0:
        log.seek(0)
        msg = log.read().decode(errors="ignore")[-400:]
        log.close()
        raise RuntimeError("FFmpeg a échoué. " + msg)
    log.close()
    progression(1.0)
    return True


def lister_videos(dossier):
    d = Path(dossier)
    return sorted(p for p in d.iterdir() if p.is_file() and p.suffix.lower() in EXT) if d.is_dir() else []


def sortie_de(video, dossier):
    return Path(dossier) / f"{video.stem}_9x16.mp4"


def mode_auto(entrees, sorties, opt, surveiller):
    Path(sorties).mkdir(parents=True, exist_ok=True)
    vues = {}
    while True:
        for v in lister_videos(entrees):
            if sortie_de(v, sorties).exists():
                continue
            taille = v.stat().st_size
            if surveiller and vues.get(v.name) != taille:   # fichier encore en copie : on attend
                vues[v.name] = taille
                continue
            print(f"▶ {v.name}")
            try:
                traiter_video(v, sortie_de(v, sorties), opt,
                              lambda f: print(f"\r  {f * 100:3.0f} %", end="", flush=True))
                print(f"\n✔ {sortie_de(v, sorties)}")
            except Exception as e:
                print(f"\n✖ {v.name} : {e}")
        if not surveiller:
            return
        time.sleep(5)


def lancer_gui():
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    racine = tk.Tk()
    racine.title("Vidéos 9:16")
    racine.geometry("620x680")
    msgs, travaux, annule, etat = queue.Queue(), queue.Queue(), threading.Event(), {"actif": False}
    a_faire, deja, vues = [], set(), {}

    v_sortie = tk.StringVar(value=str(Path.home() / "Videos_9x16"))
    v_texte = tk.StringVar(value=OPT_DEFAUT["texte"])
    v_miroir = tk.StringVar(value="5")
    v_st = tk.BooleanVar(value=True)
    v_watch = tk.StringVar()
    v_watch_on = tk.BooleanVar(value=False)

    def lire_opt():
        try:
            miroir = float(v_miroir.get().replace(",", "."))
        except ValueError:
            miroir = 0.0
        return dict(texte=v_texte.get(), miroir=miroir, sous_titres=v_st.get())

    def champ(titre, var, bouton=None):
        cadre = ttk.Frame(racine)
        cadre.pack(fill="x", padx=12, pady=3)
        ttk.Label(cadre, text=titre, width=18).pack(side="left")
        ttk.Entry(cadre, textvariable=var).pack(side="left", fill="x", expand=True)
        if bouton:
            ttk.Button(cadre, text="…", width=3, command=bouton).pack(side="left", padx=(4, 0))

    # --- Vidéos à traiter
    ttk.Label(racine, text="1. Mes vidéos", font=("", 11, "bold")).pack(anchor="w", padx=12, pady=(12, 2))
    liste = tk.Listbox(racine, height=6)
    liste.pack(fill="x", padx=12)

    def ajouter(chemins):
        for c in chemins:
            p = Path(c)
            if p not in a_faire:
                a_faire.append(p)
                liste.insert("end", p.name)

    def ajouter_fichiers():
        ajouter(filedialog.askopenfilenames(filetypes=[("Vidéos", " ".join("*" + e for e in EXT))]))

    def ajouter_dossier():
        d = filedialog.askdirectory()
        if d:
            ajouter(lister_videos(d))

    def vider():
        a_faire.clear()
        liste.delete(0, "end")

    rang = ttk.Frame(racine)
    rang.pack(fill="x", padx=12, pady=4)
    for txt, cmd in [("Ajouter des vidéos", ajouter_fichiers), ("Ajouter un dossier", ajouter_dossier), ("Vider", vider)]:
        ttk.Button(rang, text=txt, command=cmd).pack(side="left", padx=(0, 6))

    # --- Réglages
    ttk.Label(racine, text="2. Réglages", font=("", 11, "bold")).pack(anchor="w", padx=12, pady=(10, 2))
    champ("Dossier de sortie", v_sortie, lambda: v_sortie.set(filedialog.askdirectory() or v_sortie.get()))
    champ("Texte", v_texte)
    champ("Miroir (secondes)", v_miroir)
    ttk.Checkbutton(racine, text="Effacer les sous-titres (bas de l'image)", variable=v_st).pack(anchor="w", padx=12)

    # --- Automatique
    ttk.Label(racine, text="3. Automatique (facultatif)", font=("", 11, "bold")).pack(anchor="w", padx=12, pady=(10, 2))
    champ("Dossier surveillé", v_watch, lambda: v_watch.set(filedialog.askdirectory() or v_watch.get()))
    ttk.Checkbutton(racine, text="Traiter automatiquement toute nouvelle vidéo déposée dans ce dossier",
                    variable=v_watch_on).pack(anchor="w", padx=12)

    # --- Lancement
    def envoyer(v):
        travaux.put((v, v_sortie.get(), lire_opt()))

    def demarrer():
        if not a_faire:
            messagebox.showinfo("Rien à traiter", "Ajoute d'abord des vidéos.")
            return
        for v in list(a_faire):
            envoyer(v)
        vider()

    def arreter():
        while True:
            try:
                travaux.get_nowait()
            except queue.Empty:
                break
        if etat["actif"]:
            annule.set()

    rang = ttk.Frame(racine)
    rang.pack(fill="x", padx=12, pady=10)
    ttk.Button(rang, text="▶ Démarrer", command=demarrer).pack(side="left", padx=(0, 6))
    ttk.Button(rang, text="■ Arrêter", command=arreter).pack(side="left")
    barre = ttk.Progressbar(racine, maximum=100)
    barre.pack(fill="x", padx=12)
    journal = tk.Text(racine, height=8)
    journal.pack(fill="both", expand=True, padx=12, pady=8)

    def worker():
        while True:
            v, dossier, opt = travaux.get()
            etat["actif"] = True
            sortie = sortie_de(v, dossier)
            msgs.put(("log", f"▶ {v.name}"))
            try:
                Path(dossier).mkdir(parents=True, exist_ok=True)
                ok = traiter_video(v, sortie, opt, lambda f: msgs.put(("prog", f)), annule)
                msgs.put(("log", f"✔ {sortie.name}" if ok else "■ Annulé"))
            except Exception as e:
                msgs.put(("log", f"✖ {v.name} : {e}"))
            etat["actif"] = False
            if travaux.empty():
                annule.clear()
            msgs.put(("prog", 0))

    def pomper():
        while not msgs.empty():
            genre, x = msgs.get()
            if genre == "log":
                journal.insert("end", x + "\n")
                journal.see("end")
            else:
                barre["value"] = x * 100
        racine.after(150, pomper)

    def surveiller():
        if v_watch_on.get() and v_watch.get():
            for v in lister_videos(v_watch.get()):
                if v in deja or sortie_de(v, v_sortie.get()).exists():
                    continue
                taille = v.stat().st_size
                if vues.get(v.name) != taille:      # encore en cours de copie
                    vues[v.name] = taille
                    continue
                deja.add(v)
                msgs.put(("log", f"Nouvelle vidéo détectée : {v.name}"))
                envoyer(v)
        racine.after(5000, surveiller)

    threading.Thread(target=worker, daemon=True).start()
    pomper()
    surveiller()
    racine.mainloop()


def main():
    p = argparse.ArgumentParser(description="Vidéos 9:16")
    p.add_argument("--entrees", help="dossier de vidéos à traiter (mode automatique)")
    p.add_argument("--sorties", default="sorties")
    p.add_argument("--surveiller", action="store_true", help="reste actif et traite les nouvelles vidéos")
    p.add_argument("--texte", default=OPT_DEFAUT["texte"])
    p.add_argument("--miroir", type=float, default=OPT_DEFAUT["miroir"], help="0 = désactivé")
    p.add_argument("--garder-sous-titres", action="store_true")
    a = p.parse_args()

    if not shutil.which("ffmpeg"):
        sys.exit("FFmpeg est introuvable : installe-le et ajoute-le au PATH (https://ffmpeg.org).")
    if a.entrees:
        opt = dict(texte=a.texte, miroir=a.miroir, sous_titres=not a.garder_sous_titres)
        mode_auto(a.entrees, a.sorties, opt, a.surveiller)
    else:
        lancer_gui()


if __name__ == "__main__":
    main()
