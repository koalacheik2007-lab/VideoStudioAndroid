# Vidéo Studio — projet Android

Application Android native en Kotlin, adaptée du script `video_app.py` fourni.

## Fonctions prévues
- Sélection de plusieurs vidéos sur le téléphone.
- Export MP4 vertical 1080 × 1920 avec le son d'origine.
- Zoom progressif, micro-shake, miroir alterné et signature en surimpression.
- Atténuation approximative de la zone inférieure où se trouvent souvent les sous-titres.
- Enregistrement dans `Films/Video Studio`.

## Obtenir l'APK sans ordinateur

Le dépôt contient un workflow GitHub Actions qui compile automatiquement l'application et publie un APK téléchargeable. Il faut un compte GitHub et une connexion Internet.

1. Sur le téléphone, ouvrez https://github.com et connectez-vous (ou créez un compte).
2. Créez un dépôt **public** nommé `VideoStudioAndroid`.
3. Décompressez cette archive sur le téléphone avec votre gestionnaire de fichiers.
4. Dans le dépôt GitHub, choisissez **Add file → Upload files** et envoyez le contenu du dossier `VideoStudioAndroid` en conservant les dossiers (`app`, `.github` et leurs sous-dossiers). Si le navigateur mobile ne permet pas de téléverser les dossiers, activez **Version pour ordinateur** dans le navigateur ou utilisez GitHub Codespaces.
5. Validez avec **Commit changes**. Le workflow `Construire l'APK Android` démarre automatiquement.
6. Dans l'onglet **Actions**, ouvrez l'exécution terminée, puis téléchargez l'artefact `VideoStudio-debug-apk`.
7. Décompressez l'artefact téléchargé et ouvrez `app-debug.apk`. Autorisez l'installation depuis cette source si Android le demande.

Le dépôt public rend le code source visible. Ne téléversez aucune vidéo personnelle dans le dépôt.

## Limites de cette première version
- Ce paquet est le code source et le script de compilation, pas encore un APK compilé.
- L'effacement des sous-titres utilise FFmpeg `delogo` : ce n'est pas une reconstruction intelligente des pixels et le résultat dépend de l'image.
- Le cadrage est centré ; il n'y a pas encore de réglage manuel de la position du sujet.
- Le traitement s'effectue vidéo par vidéo. Prévoir assez d'espace libre et de batterie.
- La dépendance FFmpegKit utilisée dans cette version a été arrêtée en amont ; la disponibilité de l'artefact Maven peut varier. Si la compilation échoue à cette étape, il faudra remplacer cette dépendance avant de pouvoir générer l'APK.

## Compilation locale (facultatif)
Android Studio récent, JDK 17, Android SDK 35 et Gradle 8.7 sont nécessaires. Commande : `gradle :app:assembleDebug`.
