plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.revefulgurante.videostudio"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.revefulgurante.videostudio"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    // FFmpegKit community-compatible artifact. See README for build/dependency note.
    implementation("com.arthenica:ffmpeg-kit-full:6.0-2.LTS")
}
