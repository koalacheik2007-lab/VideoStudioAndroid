package com.revefulgurante.videostudio

import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val selected = mutableListOf<Uri>()
    private lateinit var selectedLabel: TextView
    private lateinit var status: TextView
    private lateinit var processButton: Button
    private lateinit var signature: EditText
    private lateinit var mirrorSeconds: EditText
    private lateinit var removeSubs: CheckBox
    private lateinit var zoom: CheckBox
    private lateinit var shake: CheckBox
    private lateinit var mirror: CheckBox
    private val worker = Executors.newSingleThreadExecutor()

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        selected.clear()
        selected.addAll(uris)
        selected.forEach { uri -> contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        selectedLabel.text = if (selected.isEmpty()) "Aucune vidéo sélectionnée" else "${selected.size} vidéo(s) sélectionnée(s)"
        processButton.isEnabled = selected.isNotEmpty()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(20))
            setBackgroundColor(0xFF101114.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "VIDÉO STUDIO"
            textSize = 26f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        content.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "Tes vidéos. Ton style. En format vertical 9:16."
            textSize = 14f; gravity = Gravity.CENTER; setTextColor(0xFFB9BBC2.toInt())
            setPadding(0, dp(6), 0, dp(22))
        }
        content.addView(subtitle, matchWrap())

        val pick = Button(this).apply { text = "＋  CHOISIR MES VIDÉOS"; setOnClickListener { picker.launch(arrayOf("video/*")) } }
        content.addView(pick, matchWrap())
        selectedLabel = label("Aucune vidéo sélectionnée")
        selectedLabel.setPadding(0, dp(10), 0, dp(18))
        content.addView(selectedLabel, matchWrap())
        section(content, "PERSONNALISATION")

        signature = EditText(this).apply {
            setSingleLine(true); hint = "Texte à afficher (ex. Rêve fulgurante)"
            setText("Rêve fulgurante"); textSize = 15f
        }
        content.addView(signature, matchWrap())
        mirrorSeconds = EditText(this).apply {
            setSingleLine(true); inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            hint = "Intervalle miroir en secondes"; setText("5")
        }
        content.addView(mirrorSeconds, matchWrap())

        removeSubs = check("Atténuer les sous-titres en bas de l'image", true)
        zoom = check("Zoom progressif", true)
        shake = check("Micro-shake", true)
        mirror = check("Effet miroir alterné", true)
        listOf(removeSubs, zoom, shake, mirror).forEach { content.addView(it, matchWrap()) }

        val note = TextView(this).apply {
            text = "Les vidéos exportées seront enregistrées dans Films/Vidéo Studio. Le son d'origine est conservé."
            textSize = 12f; setTextColor(0xFFB9BBC2.toInt()); setPadding(0, dp(12), 0, dp(16))
        }
        content.addView(note, matchWrap())
        processButton = Button(this).apply {
            text = "▶  LANCER LE TRAITEMENT"; isEnabled = false
            setOnClickListener { startBatch() }
        }
        content.addView(processButton, matchWrap())
        status = label("Prêt.")
        status.setPadding(0, dp(16), 0, dp(8))
        content.addView(status, matchWrap())
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun section(parent: LinearLayout, text: String) {
        parent.addView(TextView(this).apply {
            this.text = text; textSize = 12f; typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextColor(0xFFE45B60.toInt()); setPadding(0, dp(10), 0, dp(10))
        }, matchWrap())
    }

    private fun label(text: String) = TextView(this).apply { this.text = text; textSize = 14f; setTextColor(0xFFE7E7EA.toInt()) }
    private fun check(text: String, checked: Boolean) = CheckBox(this).apply {
        this.text = text; isChecked = checked; textSize = 14f; setTextColor(0xFFE7E7EA.toInt())
        buttonTintList = ContextCompat.getColorStateList(this@MainActivity, android.R.color.holo_red_light)
    }
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun startBatch() {
        if (selected.isEmpty()) return
        processButton.isEnabled = false
        val uris = selected.toList()
        val opts = Options(signature.text.toString(), mirrorSeconds.text.toString().toDoubleOrNull()?.coerceAtLeast(0.0) ?: 5.0,
            removeSubs.isChecked, zoom.isChecked, shake.isChecked, mirror.isChecked)
        status.text = "Préparation de ${uris.size} vidéo(s)…"
        worker.execute {
            var done = 0
            uris.forEachIndexed { index, uri ->
                runOnUiThread { status.text = "Traitement ${index + 1}/${uris.size}…" }
                try {
                    processOne(uri, opts)
                    done++
                } catch (e: Exception) {
                    runOnUiThread { status.text = "Erreur : ${e.message ?: "traitement impossible"}" }
                }
            }
            runOnUiThread {
                status.text = "$done/${uris.size} vidéo(s) exportée(s) dans Films/Vidéo Studio."
                processButton.isEnabled = selected.isNotEmpty()
            }
        }
    }

    private data class Options(val text: String, val mirrorEvery: Double, val removeSubs: Boolean, val zoom: Boolean, val shake: Boolean, val mirror: Boolean)

    private fun processOne(uri: Uri, options: Options) {
        val input = File(cacheDir, "input_${System.nanoTime()}.mp4")
        contentResolver.openInputStream(uri)?.use { source -> input.outputStream().use { source.copyTo(it) } }
            ?: throw IllegalStateException("Impossible de lire la vidéo")
        val output = File(cacheDir, "render_${System.nanoTime()}.mp4")
        val filters = mutableListOf<String>()
        // Center crop to a vertical canvas, then apply optional motion effects.
        filters += "crop='min(iw,ih*9/16)':ih:(iw-min(iw,ih*9/16))/2:0"
        filters += "scale=1080:1920:flags=lanczos"
        if (options.zoom) {
            filters += "scale=w='iw*(1+0.03*(0.5-0.5*cos(2*PI*t/20)))':h='ih*(1+0.03*(0.5-0.5*cos(2*PI*t/20)))':eval=frame"
            filters += "crop=1080:1920"
        }
        if (options.shake) filters += "crop=1080:1920:x='(in_w-out_w)/2+2*sin(t*17)':y='(in_h-out_h)/2+2*cos(t*13)'"
        if (options.mirror && options.mirrorEvery > 0) {
            val period = options.mirrorEvery * 2.0
            filters += "hflip=enable='gte(mod(t\\,$period)\\,${options.mirrorEvery})'"
        }
        if (options.removeSubs) {
            // Delogo is a lightweight approximation; it is not AI inpainting.
            filters += "delogo=x=0:y=ih*0.80:w=iw:h=ih*0.20:show=0"
        }
        if (options.text.isNotBlank()) {
            val safe = options.text.replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'").replace("%", "\\%")
            filters += "drawtext=fontfile=/system/fonts/Roboto-Bold.ttf:text='$safe':fontcolor=white:fontsize=68:x=w*0.06:y=h*0.04:shadowcolor=black@0.65:shadowx=2:shadowy=2"
        }
        val command = "-y -i ${quote(input.absolutePath)} -vf ${quoteFilter(filters.joinToString(","))} -map 0:v:0 -map 0:a? -c:v libx264 -preset ultrafast -crf 21 -pix_fmt yuv420p -c:a aac -b:a 128k -movflags +faststart ${quote(output.absolutePath)}"
        val session = FFmpegKit.execute(command)
        input.delete()
        if (!ReturnCode.isSuccess(session.returnCode) || !output.exists() || output.length() == 0L) {
            output.delete()
            throw IllegalStateException(session.failStackTrace ?: session.allLogsAsString.takeLast(500))
        }
        saveToGallery(output)
        output.delete()
    }

    private fun quote(value: String) = "'" + value.replace("'", "'\\''") + "'"
    private fun quoteFilter(value: String) = "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

    private fun saveToGallery(file: File) {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "VideoStudio_$stamp.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Video Studio")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Impossible de créer le fichier dans la galerie")
        contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
            ?: throw IllegalStateException("Impossible d'enregistrer la vidéo")
        values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0)
        contentResolver.update(uri, values, null, null)
    }

    override fun onDestroy() { super.onDestroy(); worker.shutdown() }
}
