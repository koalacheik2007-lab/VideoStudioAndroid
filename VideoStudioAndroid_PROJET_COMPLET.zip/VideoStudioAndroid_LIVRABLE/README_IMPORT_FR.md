# Vidéo Studio Android

Projet source Android Kotlin pour sélectionner plusieurs vidéos, appliquer un recadrage vertical 9:16, zoom progressif, micro-shake, miroir alterné, texte et export MP4 avec audio.

**Ce dossier est un projet source, pas un APK.** Pour les instructions d'importation depuis un téléphone et de compilation via GitHub Actions, lire `LISEZ_MOI_AVANT_IMPORTER.txt`.

Limite fonctionnelle : l'atténuation des sous-titres utilise FFmpeg `delogo` et peut laisser des traces. La dépendance FFmpegKit référencée dans `app/build.gradle.kts` peut aussi nécessiter un remplacement si elle n'est plus accessible.
